// if masala

// 1-masala

// let a =+prompt('a sonini kiriting');
// if(a > 0){
//     a = a+ 1;
//     console.log(a);
// }
// else{
//     console.log(a);
// }


// 2-masala

// let a =+prompt('a sonini kiriting');
// if(a > 0){
//     a = a + 1;
// }

// else if(a == 0){
//     a = 10;
    
// }
// else{
//     a = -a -2;
//  }
// console.log(a);



// 3-masala

// let a =+prompt('a sonini kiriting');
// let b =+prompt('b sonini kiriting');
// let c =+prompt('c sonini kiriting');
// if(Number.isInteger(a) && Number.isInteger(b) && Number.isInteger(c)){
//     console.log(`A , B , C  sonlarimiz butun`)
// }
// else if(Number.isInteger(a) && Number.isInteger(b) || Number.isInteger(a) && Number.isInteger(c) || Number.isInteger(b) && Number.isInteger(c)){
//     console.log('2 ta son butun');
// }
// else{
//     console.log('bitta son butun');
// }



// 4-masala


// let a =+prompt('a sonini kiriting');
// let b =+prompt('b sonini kiriting');
// let javob = Math.max(a,b)
// console.log(`Eng katta son ${javob}` );




// 5-masala4

// let a =+prompt('a sonini kiriting');
// let b =+prompt('b sonini kiriting');
// let javob = Math.min(a,b)
// console.log(`Eng kichkina son ${javob}` );


// 6-masala

// let a =+prompt('a sonini kiriting');
// let b =+prompt('b sonini kiriting');
// let javob = Math.max(a,b);
// let javob1 =Math.min(a,b)
// console.log(`Eng katta son ${javob}`);
// console.log(`Eng kihkina son ${javob1}`);


// 7-masala
// let a =+prompt('a sonini kiriting');
// let b =+prompt('b sonini kiriting');
// let c;
// if(a < b){
//     console.log( a, b);
// }
// else {
//     if ( a > b) {
//         c = a;
//         a = b;
//         b = c;
//         console.log( a, b );
//     }
    
// }




// 8-masala

// let a =+prompt('a sonini kiriting');
// let b =+prompt('b sonini kiriting');
// if(a != b){
//     console.log(a + b);
// }
// else if(a == b){
//     console.log(`Bu sonlar uzaro teng`);
// }




// 9-masala

// let a =+prompt('a sonini kiriting');
// let b =+prompt('b sonini kiriting');
// if(a != b){
//    console.log(Math.max(a,b));
// }
// else if(a == b){
//     console.log(`Bu sonlar uzaro teng`);
// }


// 10-masala
// let a =+prompt('a sonini kiriting');
// let b =+prompt('b sonini kiriting');
// let c =+prompt('c sonini kiriting');
// let javob=Math.min(a,b,c)

// console.log(javob);


// 11-masala

// switch case


// 1-MASALA
//  let baho =+prompt('Son kiriting');
//  let javob;
//  switch(baho){
//    case 2:
//     javob = 'juda yomon';
//     break;
//     case 3:
//         javob = 'Qoniqarsiz';
//         break;
//         case 4:
//             javob = 'Yaxshi';
//             break;
//             case 5:
//                 javob = 'Alo';
//                 break;
//                 default:
//                 javob='Bunay son mavjud emas'
 
//  }
//  console.log(javob);




// 2-masala

// let oy =+prompt('Oyni kiriting')
// let fasl;
// switch(oy){
//     case 1:
//         fasl='Bahor';
//         break;
//         case 2:
//             fasl='Bahor';
//             break;
//             case 3:
//                 fasl='Bahon';
//                 break;

//                 case 4:
//                     fasl='Yoz';
//                     break;
//                     case 5:
//                         fasl= 'Yoz';
//                         break;
//                         case 6:
//                             fasl='Yoz';
//                             break;

//                             case 7:
//                                 fasl='Kuz';
//                                 break;
//                                 case 8:
//                                     fasl= 'Kuz';
//                                     break;
//                                     case 9:
//                                         fasl='Kuz';
//                                         break;

//                                         case 10:
//                                             fasl='  qish';
//                                             break;
//                                             case 11:
//                                                 fasl= 'Qish';
//                                                 break;
//                                                 case 12:
//                                                     fasl='Qish';
//                                                     break;
//                                                     default:
//                                                         console.log('Bunay oy raqamlar yuq');




// }
// console.log(fasl);


// 3-masala

// let oy =+prompt('oy sonini kiriting');
// let javob;
// switch(oy){
//     case 1:
//         javob = 'Utttiz bir kun bor';
//         break;
//     case 2:
//     javob = 'Yegirma tuqqiz  kun bor';
//     break;
//     case 3:
//         javob = 'Utttiz bir kun bor';
//         break;
//         case 4:
//             javob = 'Utttiz  kun bor';
//             break;
//             case 5:
//                 javob = 'Utttiz bir kun bor';
//                 break;
//                 case 6:
//                     javob = 'Utttiz kun bor';
//                     break;
//                     case 7:
//                         javob = 'Utttiz bir kun bor';
//                         break;
//                         case 8:
//                             javob = 'Utttiz bir kun bor';
//                             break;
//                             case 9:
//                                 javob = 'Utttiz kun bor';
//                                 break;
//                                 case 10:
//                                     javob = 'Utttiz bir kun bor';
//                                     break;
//                                     case 11:
//                                         javob = 'Utttiz kun bor';
//                                         break;
//                                         case 12:
//                                             javob = 'Utttiz bir kun bor';
//                                             break;
//                                             default:
//                                                 console.log('bunay oy mavjud emas');
// }
// console.log(javob);

// 4-masala
// let kesma =+prompt('Kesmaning uzunligini kiriting');
// let metr;
// switch(kesma){
//     case 1:
//         metr='1 desimetr 0.1 meterga tugri keladi';
//         break;
//         case 2:
//         metr='Ikki kilometr 2000 metrga tugri keldi';
//         break;
//         case 3:
//         metr=' 3-metr 300 santimetrga tugri keldi';
//         break;
//         case 4:
//         metr='4-millimeterimiz  0.004 meterga tugri keladi';
//         break;
//         case 5:
//         metr='5-santimeterimiz 0.05 meterga tugri keladi';
//         break;
//         default:
//             console.log('Bunday son mavljud emas');
// }

// console.log(metr);

// 5-masala

// let ogir=+prompt('Kilogram kiriting');
// let kilo;
// switch(ogir){
//     case 1:
//     kilo ='1 kilogramm 1  kilogramm'
//     break;
//     case 2:
//         kilo ='2-milligramm 0.000002 kilogram'
//         break;
//         case 3:
//             kilo ='3-gram 0.003 kilogram'
//             break;
//             case 4:
//                 kilo ='4-tonna 4000 kilogram'
//                 break;
//                 case 5:
//                     kilo ='5-sentner 500 kilogram'
//                     break;
//                     default:
//                         console.log('bunday kilo mavjud emas');
// }
// console.log(kilo);

// 6-masaala


// 10-masala
// let Oquv=+prompt('Masalani kiriting');
// let savol;
// switch(Oquv){
//     case 11:
//         savol='Un birinchi masala'
//         break;
//         case 12:
//             savol='Un ikkinchi masala'
//             break;
//             case 13:
//                 savol='Un uchinchi masala'
//                 break;
//                 case 14:
//                     savol='Un turtinchi masala'
//                     break;
//                     case 15:
//                         savol='Un beshinchi masala'
//                         break;
//                         case 16:
//                             savol='Un oltinchi masala'
//                             break;
//                             case 17:
//                                 savol='Un yettinchi masala'
//                                 break;
//                                 case 18:
//                                     savol='Un sakkizinchi masala'
//                                     break;
//                                     case 19:
//                                         savol='Un tuqqizinchi masala'
//                                         break;
//                                         case 20:
//                                             savol='Yigirmanchi masala'
//                                             break;
        
//                                             case 21:
//                                                 savol='Yigirma birinchi masala'
//                                                 break;
        
//                                                 case 22:
//                                                     savol='Yigirma ikkinchi masala'
//                                                     break;
        
//                                                     case 23:
//                                                         savol='Yigirma uchinchi  masala'
//                                                         break;
//                                                         case 24:
//                                                             savol='Yigirma turttinchi  masala'
//                                                             break;  
//                                                             case 25:
//                                                             savol='Yigirma beshinchi   masala'
//                                                             break;
//                                                             case 26:
//                                                                 savol='Yigirma oltincchi masala'
//                                                                 break;
//                                                                 case 27:
//                                                                     savol='Yigirma  yettinchi masala'
//                                                                     break;
//                                                                 case 28:
//                                                                 savol='Yigirma sakkizinchi masala'
//                                                                 break;
//                                                                 case 29:
//                                                                     savol='Yigirma tuqqizinchi masala'
//                                                                     break;
//                                                                     case 30:
//                                                                         savol='Uttiz masala'
//                                                                         break;
//                                                                         case 31:
//                                                                             savol='Uttiz birinchi masala'
//                                                                             break;
//                                                                             case 32:
//                                                                                 savol='Uttiz ikkinchi masala'
//                                                                                 break;
//                                                                                 case 33:
//                                                                                     savol='Uttiz uchinchi masala'
//                                                                                     break;
//                                                                                     case 34:
//                                                                                         savol='Uttiz turtinchi masala'
//                                                                                         break;
//                                                                                         case 35:
//                                                                                             savol='Uttiz besdhinchi masala'
//                                                                                             break;
//                                                                                             case 36:
//                                                                                                 savol='Uttiz oltinchi masala'
//                                                                                                 break;
//                                                                                                 case 37:
//                                                                                                     savol='Uttiz yettinchi masala'
//                                                                                                     break;
//                                                                                                     case 38:
//                                                                                                         savol='Uttiz sakkizinchi masala'
//                                                                                                         break;
//                                                                                                         case 39:
//                                                                                                             savol='Uttiz tuqqiznchi masala'
//                                                                                                             break;
//                                                                                                             case 40:
//                                                                                                                 savol='Qirqinchi masala'
//                                                                                                                 break;
//                                                                                                                 default:
//                                                                                                                     console.log('bunmday masala mavkjud emas');
                                                                                        
                                                                                                                                                                                                                                                                                                                                                                                                                                            
                                                                
                                                                                                            
                                                                                                                                                        
// }
// console.log(savol);